﻿namespace smarthometec_API.reportes
{
}

namespace smarthometec_API.reportes
{
}

namespace smarthometec_API.reportes
{
}

namespace smarthometec_API.reportes
{
}

namespace smarthometec_API.reportes
{
}

namespace smarthometec_API.reportes
{
}

namespace smarthometec_API.reportes
{
}